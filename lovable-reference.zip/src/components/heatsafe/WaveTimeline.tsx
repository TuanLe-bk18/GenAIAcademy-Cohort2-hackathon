import type { PauseWave } from "@/lib/heatsafe/types";

export function WaveTimeline({ waves, totalMinutes = 60 }: { waves: PauseWave[]; totalMinutes?: number }) {
  const marks = [0, 15, 30, 45, 60];
  return (
    <div className="space-y-2">
      <div className="relative h-3">
        {marks.map((m) => (
          <div
            key={m}
            className="absolute top-0 h-full border-l border-hairline/60"
            style={{ left: `${(m / totalMinutes) * 100}%` }}
          />
        ))}
      </div>
      <div className="space-y-1.5">
        {waves.map((w) => {
          const left = (w.startMinute / totalMinutes) * 100;
          const width = (w.minutes / totalMinutes) * 100;
          return (
            <div key={w.index} className="relative h-8">
              <div className="absolute inset-y-0 left-0 right-0 rounded bg-surface-2/60" />
              <div
                className="absolute inset-y-0 flex items-center gap-2 rounded px-2 heat-bg-3 border border-heat-3/40"
                style={{ left: `${left}%`, width: `${width}%`, minWidth: 60 }}
              >
                <span className="text-[11px] font-semibold">W{w.index}</span>
                <span className="num text-[11px]">{w.drivers} drivers</span>
                <span className="text-[10px] text-current/70">· {w.minutes}m</span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex justify-between text-[10px] text-muted-foreground num">
        {marks.map((m) => <span key={m}>+{m}m</span>)}
      </div>
    </div>
  );
}