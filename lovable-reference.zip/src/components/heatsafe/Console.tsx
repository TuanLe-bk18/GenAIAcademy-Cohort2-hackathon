import { useMemo, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, ChevronRight, Clock, Database, MapPin, Radio, Shield, Sparkles, Thermometer, TrendingDown, Users, Wallet, Wind, X, Circle, History } from "lucide-react";
import { cityKpis, plansFor, zones, heatLabel } from "@/lib/heatsafe/data";
import type { AuditEntry, Plan, Zone } from "@/lib/heatsafe/types";
import { HeatChip } from "./HeatChip";
import { Sparkline } from "./Sparkline";
import { WaveTimeline } from "./WaveTimeline";
import { cn } from "@/lib/utils";

type Mode = "normal" | "stale" | "unavailable";

export function Console() {
  const [zoneId, setZoneId] = useState<string>(zones[0].id);
  const [planId, setPlanId] = useState<string>("safepause-staggered");
  const [mode, setMode] = useState<Mode>("normal");
  const [confirming, setConfirming] = useState(false);
  const [audit, setAudit] = useState<AuditEntry[]>([
    {
      id: "sim-001",
      timestamp: "12:14:02",
      zone: "Đống Đa",
      plan: "SafePause · 2 waves",
      driversPaused: 22,
      operator: "an.pham@ops",
      simulated: true,
      note: "Pre-peak protection",
    },
  ]);
  const [showAudit, setShowAudit] = useState(false);
  const [lastRecorded, setLastRecorded] = useState<string | null>(null);

  const zone = useMemo(() => zones.find((z) => z.id === zoneId)!, [zoneId]);
  const plans = useMemo(() => plansFor(zone.id), [zone.id]);
  const plan = useMemo(() => plans.find((p) => p.id === planId) ?? plans[0], [plans, planId]);
  const recommended = plans.find((p) => p.isRecommended)!;

  const aiOk = mode === "normal";
  const stale = mode === "stale";
  const down = mode === "unavailable";

  const confirmSim = () => {
    const now = new Date();
    const entry: AuditEntry = {
      id: `sim-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: now.toTimeString().slice(0, 8),
      zone: zone.name,
      plan: plan.label,
      driversPaused: plan.driversPaused,
      operator: "an.pham@ops",
      simulated: true,
    };
    setAudit((a) => [entry, ...a]);
    setLastRecorded(entry.id);
    setConfirming(false);
    setTimeout(() => setLastRecorded(null), 6000);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <TopBar mode={mode} setMode={setMode} onAudit={() => setShowAudit(true)} auditCount={audit.length} />

      <div className="mx-auto grid max-w-[1600px] grid-cols-12 gap-4 px-6 py-5">
        {/* LEFT — City + zones */}
        <aside className="col-span-12 lg:col-span-3 space-y-4">
          <CityPanel stale={stale} down={down} />
          <ZoneList zones={zones} selectedId={zone.id} onSelect={setZoneId} />
        </aside>

        {/* CENTER — Zone brief + recommendation + tradeoffs */}
        <main className="col-span-12 lg:col-span-6 space-y-4">
          <ZoneHeader zone={zone} />
          <RecommendationCard
            zone={zone}
            plans={plans}
            plan={plan}
            setPlanId={setPlanId}
            recommended={recommended}
            down={down}
            stale={stale}
          />
          <TradeoffsMatrix plans={plans} selectedId={plan.id} onSelect={setPlanId} down={down} />
        </main>

        {/* RIGHT — Impact + confirm */}
        <aside className="col-span-12 lg:col-span-3 space-y-4">
          <ImpactPanel plan={plan} zone={zone} down={down} />
          <ConfirmPanel
            plan={plan}
            zone={zone}
            onConfirm={() => setConfirming(true)}
            disabled={down}
          />
          {lastRecorded && <RecordedToast onDismiss={() => setLastRecorded(null)} />}
          <ProvenancePanel />
        </aside>
      </div>

      {confirming && (
        <ConfirmDialog
          plan={plan}
          zone={zone}
          onCancel={() => setConfirming(false)}
          onConfirm={confirmSim}
        />
      )}

      {showAudit && <AuditDrawer entries={audit} onClose={() => setShowAudit(false)} />}
    </div>
  );
}

/* ————————————————— Top bar ————————————————— */
function TopBar({ mode, setMode, onAudit, auditCount }: { mode: Mode; setMode: (m: Mode) => void; onAudit: () => void; auditCount: number }) {
  const aiOk = mode === "normal";
  return (
    <header className="sticky top-0 z-30 border-b border-hairline bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-[1600px] items-center gap-4 px-6 py-3">
        <div className="flex items-center gap-2.5">
          <div className="relative h-7 w-7 rounded-md bg-gradient-to-br from-heat-4 to-heat-5 grid place-items-center">
            <Shield className="h-3.5 w-3.5 text-background" strokeWidth={2.5} />
            <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-cool ring-2 ring-background" />
          </div>
          <div className="leading-tight">
            <div className="text-[13px] font-semibold tracking-tight">HeatSafe <span className="text-muted-foreground font-normal">AI Ops</span></div>
            <div className="text-[10px] text-muted-foreground">Hanoi · Heatwave replay · 14 Jul, 12:47</div>
          </div>
        </div>

        <div className="ml-6 hidden md:flex items-center gap-3 text-[11px] text-muted-foreground">
          <StatusPill
            tone={aiOk ? "ok" : mode === "stale" ? "warn" : "crit"}
            icon={aiOk ? <Sparkles className="h-3 w-3" /> : mode === "stale" ? <Clock className="h-3 w-3" /> : <AlertTriangle className="h-3 w-3" />}
            label={aiOk ? "AI ready · v0.9.3" : mode === "stale" ? "Data stale · 4m 12s" : "AI unavailable — monitoring only"}
          />
          <StatusPill tone="muted" icon={<Database className="h-3 w-3" />} label="BQ + BQML + Gemini" />
          <StatusPill tone="muted" icon={<Radio className="h-3 w-3" />} label="42s ago" />
        </div>

        <div className="ml-auto flex items-center gap-2">
          <div className="hidden md:flex items-center rounded-md border border-hairline bg-surface p-0.5 text-[11px]">
            {(["normal", "stale", "unavailable"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={cn(
                  "px-2 py-1 rounded transition-colors",
                  mode === m ? "bg-surface-2 text-foreground" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {m === "normal" ? "AI ready" : m === "stale" ? "Stale data" : "AI down"}
              </button>
            ))}
          </div>
          <button
            onClick={onAudit}
            className="inline-flex items-center gap-1.5 rounded-md border border-hairline bg-surface px-2.5 py-1.5 text-[11px] hover:bg-surface-2"
          >
            <History className="h-3.5 w-3.5" />
            Simulation log
            <span className="num rounded bg-surface-2 px-1.5 py-0.5 text-[10px]">{auditCount}</span>
          </button>
          <div className="hidden md:flex items-center gap-2 rounded-md border border-hairline bg-surface px-2.5 py-1 text-[11px]">
            <div className="h-5 w-5 rounded-full bg-cool/30 text-cool grid place-items-center text-[10px] font-semibold">AP</div>
            <span>an.pham@ops</span>
          </div>
        </div>
      </div>

      <div className="border-t border-hairline bg-surface/40">
        <div className="mx-auto flex max-w-[1600px] items-center gap-2 px-6 py-1.5 text-[11px] text-muted-foreground">
          <span className="text-heat-3">●</span>
          <span>
            Simulation environment · Confirming a plan records a decision only. No commands are dispatched to drivers.
          </span>
        </div>
      </div>
    </header>
  );
}

function StatusPill({ tone, icon, label }: { tone: "ok" | "warn" | "crit" | "muted"; icon: React.ReactNode; label: string }) {
  const toneCls =
    tone === "ok" ? "text-ok border-ok/30 bg-ok/10"
    : tone === "warn" ? "text-warn border-warn/30 bg-warn/10"
    : tone === "crit" ? "text-crit border-crit/30 bg-crit/10"
    : "text-muted-foreground border-hairline bg-surface";
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5", toneCls)}>
      {icon}
      {label}
    </span>
  );
}

/* ————————————————— City panel ————————————————— */
function CityPanel({ stale, down }: { stale: boolean; down: boolean }) {
  return (
    <section className="rounded-lg border border-hairline bg-surface">
      <div className="flex items-center justify-between border-b border-hairline px-4 py-2.5">
        <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Hanoi · Live</div>
        <span className={cn("text-[10px] num", stale ? "text-warn" : "text-muted-foreground")}>{stale ? "4m 12s ago" : "42s ago"}</span>
      </div>
      <div className="grid grid-cols-2 gap-px bg-hairline">
        <Kpi label="Active drivers" value={cityKpis.activeDrivers} icon={<Users className="h-3.5 w-3.5" />} />
        <Kpi label="Escalations (60m)" value={`+${cityKpis.expectedEscalations60}`} icon={<TrendingDown className="h-3.5 w-3.5 rotate-180" />} tone="warn" />
        <Kpi label="Exposed 4h+" value={cityKpis.exposed4h} icon={<Clock className="h-3.5 w-3.5" />} tone="heat" />
        <Kpi label="Zones needing action" value={`${cityKpis.zonesRequiringAction} / ${zones.length}`} icon={<MapPin className="h-3.5 w-3.5" />} />
      </div>
      {(stale || down) && (
        <div className="border-t border-hairline px-4 py-2 text-[11px] text-warn flex items-start gap-2">
          <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
          <span>
            {down
              ? "AI recommendations paused. Monitoring KPIs and CoolStop availability remain live. No plan is generated while evidence is unavailable."
              : "Data feed older than 3m. Recommendations shown but flagged; confirm only if the situation matches ground truth."}
          </span>
        </div>
      )}
    </section>
  );
}

function Kpi({ label, value, icon, tone = "default" }: { label: string; value: React.ReactNode; icon: React.ReactNode; tone?: "default" | "warn" | "heat" }) {
  const cls = tone === "warn" ? "text-warn" : tone === "heat" ? "text-heat-4" : "text-foreground";
  return (
    <div className="bg-surface px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className={cn("num mt-1 text-lg font-semibold", cls)}>{value}</div>
    </div>
  );
}

/* ————————————————— Zone list ————————————————— */
function ZoneList({ zones, selectedId, onSelect }: { zones: Zone[]; selectedId: string; onSelect: (id: string) => void }) {
  return (
    <section className="rounded-lg border border-hairline bg-surface">
      <div className="flex items-center justify-between border-b border-hairline px-4 py-2.5">
        <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Zones · sorted by urgency</div>
      </div>
      <ul className="divide-y divide-hairline">
        {zones.map((z) => {
          const selected = z.id === selectedId;
          return (
            <li key={z.id}>
              <button
                onClick={() => onSelect(z.id)}
                className={cn(
                  "w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-surface-2 transition-colors",
                  selected && "bg-surface-2 border-l-2 border-heat-4 pl-[14px]",
                )}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] font-semibold truncate">{z.name}</span>
                    <HeatChip band={z.band} showLabel={false} size="xs" />
                  </div>
                  <div className="mt-0.5 flex items-center gap-3 text-[11px] text-muted-foreground">
                    <span className="num flex items-center gap-1"><Thermometer className="h-3 w-3" />{z.heatIndexC.toFixed(1)}°</span>
                    <span className="num flex items-center gap-1"><Users className="h-3 w-3" />{z.activeDrivers}</span>
                    <span className="num flex items-center gap-1 text-heat-4"><Clock className="h-3 w-3" />{z.exposed4h}</span>
                  </div>
                </div>
                <Sparkline data={z.trend} color={z.band >= 4 ? "var(--heat-5)" : "var(--heat-3)"} width={64} height={22} />
                <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

/* ————————————————— Zone header ————————————————— */
function ZoneHeader({ zone }: { zone: Zone }) {
  return (
    <section className="rounded-lg border border-hairline bg-surface p-5">
      <div className="flex items-start justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-muted-foreground">
            <MapPin className="h-3 w-3" /> Selected zone
          </div>
          <div className="mt-1 flex items-baseline gap-3">
            <h1 className="text-2xl font-semibold tracking-tight">{zone.name}</h1>
            <span className="text-[12px] text-muted-foreground">{zone.district}</span>
            <HeatChip band={zone.band} />
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-6">
            <Stat label="Heat Index" value={`${zone.heatIndexC.toFixed(1)}°C`} sub={heatLabel(zone.band)} tone="heat" />
            <Stat label="Active drivers" value={zone.activeDrivers} />
            <Stat label="Exposed 4h+" value={zone.exposed4h} sub="mandatory priority" tone="heat" />
            <Stat label="Eligible pool" value={zone.eligible} />
            <Stat label="Demand · next 60m" value={zone.forecastDemand60} sub="rides forecast" />
          </div>
        </div>
        <div className="w-40 shrink-0 rounded-md border border-hairline bg-surface-2 p-3">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground flex items-center gap-1">
            <Thermometer className="h-3 w-3" /> Heat trend · 60m
          </div>
          <Sparkline data={zone.trend} color="var(--heat-5)" width={128} height={40} />
          <div className="num mt-1 text-[10px] text-muted-foreground">
            {zone.trend[0].toFixed(1)}° → <span className="text-heat-4">{zone.trend[zone.trend.length - 1].toFixed(1)}°</span>
          </div>
        </div>
      </div>
      {zone.coolStop && (
        <div className="mt-4 flex items-center gap-3 rounded-md border border-cool/20 bg-cool/5 px-3 py-2 text-[12px]">
          <Wind className="h-4 w-4 text-cool" />
          <div>
            <span className="font-medium">{zone.coolStop.name}</span>
            <span className="text-muted-foreground"> · {zone.coolStop.partner}</span>
          </div>
          <div className="ml-auto flex items-center gap-4 text-muted-foreground">
            <span className="num">{zone.coolStop.distanceKm} km</span>
            <span className="num">cap {zone.coolStop.capacity}</span>
          </div>
        </div>
      )}
    </section>
  );
}

function Stat({ label, value, sub, tone = "default" }: { label: string; value: React.ReactNode; sub?: string; tone?: "default" | "heat" }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={cn("num text-lg font-semibold leading-tight", tone === "heat" && "text-heat-4")}>{value}</div>
      {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

/* ————————————————— Recommendation ————————————————— */
function RecommendationCard({ zone, plans, plan, setPlanId, recommended, down, stale }: { zone: Zone; plans: Plan[]; plan: Plan; setPlanId: (id: string) => void; recommended: Plan; down: boolean; stale: boolean }) {
  if (down) {
    return (
      <section className="rounded-lg border border-warn/30 bg-warn/5 p-5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-warn mt-0.5" />
          <div>
            <div className="text-[13px] font-semibold">No recommendation available</div>
            <p className="mt-1 text-[12px] text-muted-foreground max-w-xl">
              Model evidence is unavailable. HeatSafe will not invent a plan. You can continue to monitor {zone.name}, contact drivers manually, or wait for AI to recover.
            </p>
            <div className="mt-3 flex gap-2 text-[11px]">
              <span className="rounded border border-hairline bg-surface px-2 py-1">Monitoring: live</span>
              <span className="rounded border border-hairline bg-surface px-2 py-1">CoolStops: reachable</span>
              <span className="rounded border border-hairline bg-surface px-2 py-1">Last model output: 12:41</span>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="rounded-lg border border-heat-4/40 bg-gradient-to-br from-heat-4/5 to-transparent">
      <div className="flex items-center justify-between border-b border-heat-4/20 px-5 py-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-heat-4" />
          <span className="text-[11px] font-medium uppercase tracking-wider text-heat-4">HeatSafe recommends</span>
          {plan.id !== recommended.id && (
            <span className="text-[11px] text-muted-foreground">— viewing alternative</span>
          )}
          {stale && <span className="text-[10px] text-warn ml-2">· based on stale data</span>}
        </div>
        <div className="flex items-center gap-1 rounded-md border border-hairline bg-surface p-0.5 text-[11px]">
          {plans.map((p) => (
            <button
              key={p.id}
              onClick={() => setPlanId(p.id)}
              disabled={!!p.infeasibleReason && plan.id !== p.id}
              className={cn(
                "rounded px-2 py-1 transition-colors",
                plan.id === p.id ? "bg-surface-2 text-foreground" : "text-muted-foreground hover:text-foreground",
                p.infeasibleReason && "line-through opacity-60",
              )}
              title={p.infeasibleReason ?? p.label}
            >
              {p.isRecommended ? "Recommended" : p.id === "safepause-minimal" ? "Minimal" : "Aggressive"}
            </button>
          ))}
        </div>
      </div>

      <div className="p-5 space-y-4">
        <div className="flex items-baseline justify-between gap-6">
          <div>
            <div className="text-[18px] font-semibold tracking-tight">{plan.label}</div>
            <p className="mt-1 text-[12px] text-muted-foreground max-w-xl">{plan.rationale}</p>
          </div>
          <div className="text-right">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Drivers paused</div>
            <div className="num text-3xl font-semibold text-heat-4">{plan.driversPaused}</div>
            <div className="text-[10px] text-muted-foreground">of {zone.eligible} eligible</div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricBox icon={<Shield className="h-3.5 w-3.5" />} label="Risk reduction" value={`−${plan.riskReductionPct}%`} sub="model estimate" tone="cool" />
          <MetricBox icon={<Clock className="h-3.5 w-3.5" />} label="Recovery time" value={`${plan.recoveryMinutes}m`} sub="per wave" />
          <MetricBox icon={<CheckCircle2 className="h-3.5 w-3.5" />} label="Mandatory covered" value={plan.mandatoryCovered ? "100%" : "Partial"} sub={`${zone.mandatory} drivers`} tone={plan.mandatoryCovered ? "ok" : "warn"} />
          <MetricBox icon={<Wallet className="h-3.5 w-3.5" />} label="Earnings Guard" value={`$${plan.earningsGuardUsd.toFixed(0)}`} sub="bounded support" />
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Staggered waves · next 60 min</div>
            <div className="text-[10px] text-muted-foreground">preserves supply above demand</div>
          </div>
          <WaveTimeline waves={plan.waves} />
        </div>
      </div>
    </section>
  );
}

function MetricBox({ icon, label, value, sub, tone = "default" }: { icon: React.ReactNode; label: string; value: React.ReactNode; sub?: string; tone?: "default" | "cool" | "ok" | "warn" }) {
  const cls = tone === "cool" ? "text-cool" : tone === "ok" ? "text-ok" : tone === "warn" ? "text-warn" : "text-foreground";
  return (
    <div className="rounded-md border border-hairline bg-surface/60 px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
        {icon}{label}
      </div>
      <div className={cn("num mt-1 text-lg font-semibold", cls)}>{value}</div>
      {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

/* ————————————————— Tradeoffs matrix ————————————————— */
function TradeoffsMatrix({ plans, selectedId, onSelect, down }: { plans: Plan[]; selectedId: string; onSelect: (id: string) => void; down: boolean }) {
  if (down) return null;
  return (
    <section className="rounded-lg border border-hairline bg-surface">
      <div className="flex items-center justify-between border-b border-hairline px-5 py-3">
        <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Compare feasible plans</div>
        <div className="text-[10px] text-muted-foreground">Driver benefit vs business impact · both visible</div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[12px]">
          <thead>
            <tr className="border-b border-hairline text-[10px] uppercase tracking-wide text-muted-foreground">
              <th className="text-left font-medium px-4 py-2">Plan</th>
              <th className="text-right font-medium px-3 py-2">Paused</th>
              <th className="text-right font-medium px-3 py-2 text-cool">Risk ↓</th>
              <th className="text-right font-medium px-3 py-2">Fulfillment</th>
              <th className="text-right font-medium px-3 py-2">ETA</th>
              <th className="text-right font-medium px-3 py-2">Net cost</th>
              <th className="text-left font-medium px-3 py-2">Guardrails</th>
            </tr>
          </thead>
          <tbody>
            {plans.map((p) => {
              const infeasible = !!p.infeasibleReason;
              const selected = p.id === selectedId;
              return (
                <tr
                  key={p.id}
                  onClick={() => !infeasible && onSelect(p.id)}
                  className={cn(
                    "border-b border-hairline/60 last:border-b-0 transition-colors",
                    infeasible ? "opacity-60 cursor-not-allowed" : "cursor-pointer hover:bg-surface-2",
                    selected && "bg-surface-2",
                  )}
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Circle className={cn("h-3 w-3", selected ? "fill-heat-4 text-heat-4" : "text-muted-foreground")} strokeWidth={2} />
                      <div>
                        <div className="font-medium">{p.label}</div>
                        {p.isRecommended && <div className="text-[10px] text-heat-4">Recommended</div>}
                      </div>
                    </div>
                  </td>
                  <td className="num text-right px-3">{p.driversPaused}</td>
                  <td className="num text-right px-3 text-cool">−{p.riskReductionPct}%</td>
                  <td className={cn("num text-right px-3", p.fulfillmentImpactPct < -5 ? "text-warn" : "")}>{p.fulfillmentImpactPct}%</td>
                  <td className={cn("num text-right px-3", p.etaImpactSec > 60 ? "text-crit" : "")}>+{p.etaImpactSec}s</td>
                  <td className="num text-right px-3">${p.netCostUsd.toFixed(0)}<span className="text-muted-foreground">/{p.costLimitUsd}</span></td>
                  <td className="px-3">
                    {infeasible ? (
                      <span className="inline-flex items-center gap-1 rounded bg-crit/10 text-crit px-1.5 py-0.5 text-[10px]">
                        <AlertTriangle className="h-3 w-3" /> {p.infeasibleReason}
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded bg-ok/10 text-ok px-1.5 py-0.5 text-[10px]">
                        <CheckCircle2 className="h-3 w-3" /> Within limits
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

/* ————————————————— Impact panel ————————————————— */
function ImpactPanel({ plan, zone, down }: { plan: Plan; zone: Zone; down: boolean }) {
  if (down) {
    return (
      <section className="rounded-lg border border-hairline bg-surface p-4">
        <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Impact</div>
        <div className="mt-2 text-[12px] text-muted-foreground">Impact projections require live AI. Monitoring only.</div>
      </section>
    );
  }
  const costPct = Math.min(100, (plan.netCostUsd / plan.costLimitUsd) * 100);
  return (
    <section className="rounded-lg border border-hairline bg-surface">
      <div className="border-b border-hairline px-4 py-2.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        Business impact · stress case
      </div>
      <div className="p-4 space-y-4">
        <BarRow label="Fulfillment" value={`${plan.fulfillmentImpactPct}%`} pct={Math.min(100, Math.abs(plan.fulfillmentImpactPct) * 12)} tone={plan.fulfillmentImpactPct < -5 ? "warn" : "ok"} caption={`guardrail −6% · demand ${zone.forecastDemand60}`} />
        <BarRow label="ETA impact" value={`+${plan.etaImpactSec}s`} pct={Math.min(100, (plan.etaImpactSec / 90) * 100)} tone={plan.etaImpactSec > 60 ? "crit" : "ok"} caption="guardrail +60s" />
        <BarRow label="Net platform cost" value={`$${plan.netCostUsd.toFixed(0)}`} pct={costPct} tone={costPct > 90 ? "warn" : "ok"} caption={`limit $${plan.costLimitUsd}`} />

        <div className="rounded-md border border-cool/25 bg-cool/5 p-3">
          <div className="text-[10px] uppercase tracking-wide text-cool">Driver benefit</div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="num text-xl font-semibold text-cool">{plan.driversPaused}</span>
            <span className="text-[12px] text-muted-foreground">drivers protected · {plan.recoveryMinutes}m recovery</span>
          </div>
          <div className="mt-1 text-[11px] text-muted-foreground">
            All {zone.mandatory} mandatory-priority drivers covered. Earnings Guard: ${plan.earningsGuardUsd.toFixed(0)}.
          </div>
        </div>
      </div>
    </section>
  );
}

function BarRow({ label, value, pct, tone, caption }: { label: string; value: string; pct: number; tone: "ok" | "warn" | "crit"; caption: string }) {
  const bar = tone === "crit" ? "bg-crit" : tone === "warn" ? "bg-warn" : "bg-ok";
  return (
    <div>
      <div className="flex items-baseline justify-between text-[11px]">
        <span className="text-muted-foreground">{label}</span>
        <span className={cn("num font-semibold", tone === "crit" ? "text-crit" : tone === "warn" ? "text-warn" : "text-foreground")}>{value}</span>
      </div>
      <div className="mt-1 h-1.5 rounded-full bg-surface-2 overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", bar)} style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-1 text-[10px] text-muted-foreground">{caption}</div>
    </div>
  );
}

/* ————————————————— Confirm panel ————————————————— */
function ConfirmPanel({ plan, zone, onConfirm, disabled }: { plan: Plan; zone: Zone; onConfirm: () => void; disabled: boolean }) {
  return (
    <section className="rounded-lg border border-hairline bg-surface p-4">
      <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Confirm decision</div>
      <div className="mt-3 space-y-2 text-[12px]">
        <Line k="Zone" v={zone.name} />
        <Line k="Plan" v={plan.label} />
        <Line k="Drivers paused" v={<span className="num">{plan.driversPaused}</span>} />
        <Line k="Waves" v={<span className="num">{plan.waves.length} · {plan.recoveryMinutes}m each</span>} />
      </div>
      <button
        onClick={onConfirm}
        disabled={disabled}
        className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-[13px] font-semibold text-primary-foreground shadow-sm hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed transition"
      >
        <Shield className="h-4 w-4" /> Confirm simulation
      </button>
      <div className="mt-2 text-[10px] leading-relaxed text-muted-foreground">
        Records a decision in the audit log. No commands are sent to drivers. Reversible until deployed.
      </div>
    </section>
  );
}

function Line({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-hairline/50 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{k}</span>
      <span className="text-foreground">{v}</span>
    </div>
  );
}

/* ————————————————— Provenance ————————————————— */
function ProvenancePanel() {
  return (
    <section className="rounded-lg border border-hairline bg-surface/60 p-4 text-[11px] text-muted-foreground">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
        <Activity className="h-3 w-3" /> Model provenance
      </div>
      <ul className="mt-2 space-y-1">
        <li>· heatsafe-risk-bqml <span className="num text-foreground/80">v0.9.3</span> · trained 12 Jul</li>
        <li>· demand-forecast <span className="num text-foreground/80">v2.1</span> · MAPE 8.4%</li>
        <li>· Gemini rationale · reviewed by policy filter</li>
      </ul>
      <div className="mt-2 text-[10px] text-muted-foreground/80">
        Heat Index is a screening indicator, not a medical diagnosis. Risk reduction is a model estimate, not guaranteed prevention.
      </div>
    </section>
  );
}

/* ————————————————— Confirm dialog ————————————————— */
function ConfirmDialog({ plan, zone, onCancel, onConfirm }: { plan: Plan; zone: Zone; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/70 backdrop-blur-sm px-4">
      <div className="w-full max-w-lg rounded-lg border border-hairline bg-surface shadow-2xl">
        <div className="flex items-center justify-between border-b border-hairline px-5 py-3">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-heat-4" />
            <span className="text-[13px] font-semibold">Record simulated decision</span>
          </div>
          <button onClick={onCancel} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>
        <div className="p-5 space-y-4 text-[13px]">
          <p className="text-muted-foreground">
            You are about to record a <span className="text-foreground font-medium">SafePause simulation</span> for {zone.name}. No drivers will be paused. This will appear in the audit log with your operator ID.
          </p>
          <div className="rounded-md border border-hairline bg-surface-2/60 p-3 space-y-1.5 text-[12px]">
            <Line k="Zone" v={`${zone.name} · Heat ${zone.heatIndexC.toFixed(1)}°C`} />
            <Line k="Plan" v={plan.label} />
            <Line k="Drivers paused" v={<span className="num">{plan.driversPaused} across {plan.waves.length} waves</span>} />
            <Line k="Recovery" v={<span className="num">{plan.recoveryMinutes} minutes per wave</span>} />
            <Line k="Earnings Guard" v={<span className="num">${plan.earningsGuardUsd.toFixed(0)}</span>} />
            <Line k="Estimated risk ↓" v={<span className="num text-cool">−{plan.riskReductionPct}%</span>} />
          </div>
          <label className="flex items-start gap-2 text-[12px] text-muted-foreground">
            <input type="checkbox" defaultChecked className="mt-0.5 accent-heat-4" />
            I understand this is a simulation and no dispatch command will be sent.
          </label>
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-hairline px-5 py-3">
          <button onClick={onCancel} className="rounded-md border border-hairline bg-surface px-3 py-1.5 text-[12px] hover:bg-surface-2">Cancel</button>
          <button onClick={onConfirm} className="rounded-md bg-primary px-4 py-1.5 text-[12px] font-semibold text-primary-foreground hover:brightness-110">
            Record simulation
          </button>
        </div>
      </div>
    </div>
  );
}

/* ————————————————— Recorded toast ————————————————— */
function RecordedToast({ onDismiss }: { onDismiss: () => void }) {
  return (
    <div className="rounded-lg border border-ok/40 bg-ok/10 p-3 flex items-start gap-2 text-[12px]">
      <CheckCircle2 className="h-4 w-4 text-ok mt-0.5" />
      <div className="flex-1">
        <div className="font-medium text-ok">Simulation recorded</div>
        <div className="text-muted-foreground">Added to audit log. No dispatch command sent.</div>
      </div>
      <button onClick={onDismiss} className="text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5" /></button>
    </div>
  );
}

/* ————————————————— Audit drawer ————————————————— */
function AuditDrawer({ entries, onClose }: { entries: AuditEntry[]; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-40 flex" onClick={onClose}>
      <div className="flex-1 bg-background/60 backdrop-blur-sm" />
      <aside
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md border-l border-hairline bg-surface shadow-2xl overflow-y-auto"
      >
        <div className="sticky top-0 flex items-center justify-between border-b border-hairline bg-surface px-5 py-3">
          <div>
            <div className="text-[13px] font-semibold">Simulation audit log</div>
            <div className="text-[10px] text-muted-foreground">Every confirmation is recorded here. No dispatch commands sent.</div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>
        <ul className="divide-y divide-hairline">
          {entries.map((e) => (
            <li key={e.id} className="px-5 py-3">
              <div className="flex items-center justify-between">
                <div className="text-[13px] font-medium">{e.zone}</div>
                <span className="num text-[11px] text-muted-foreground">{e.timestamp}</span>
              </div>
              <div className="text-[12px] text-muted-foreground">{e.plan}</div>
              <div className="mt-1 flex items-center gap-3 text-[11px]">
                <span className="num">{e.driversPaused} drivers</span>
                <span className="rounded bg-cool/10 text-cool px-1.5 py-0.5 text-[10px]">SIMULATED</span>
                <span className="text-muted-foreground">by {e.operator}</span>
              </div>
            </li>
          ))}
          {entries.length === 0 && (
            <li className="px-5 py-8 text-center text-[12px] text-muted-foreground">No simulations recorded yet.</li>
          )}
        </ul>
      </aside>
    </div>
  );
}