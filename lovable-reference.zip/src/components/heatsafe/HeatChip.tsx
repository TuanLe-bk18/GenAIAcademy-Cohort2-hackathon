import { cn } from "@/lib/utils";
import { heatLabel } from "@/lib/heatsafe/data";
import type { HeatBand } from "@/lib/heatsafe/types";

const map: Record<HeatBand, string> = {
  1: "heat-bg-1",
  2: "heat-bg-2",
  3: "heat-bg-3",
  4: "heat-bg-4",
  5: "heat-bg-5",
};

export function HeatChip({ band, className, showLabel = true, size = "sm" }: { band: HeatBand; className?: string; showLabel?: boolean; size?: "sm" | "xs" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full font-medium",
        map[band],
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-1.5 py-0.5 text-[10px]",
        className,
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {showLabel ? heatLabel(band) : `Band ${band}`}
    </span>
  );
}