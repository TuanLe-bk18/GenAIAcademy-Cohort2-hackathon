import type { CityKpis, HeatBand, Plan, Zone } from "./types";

function bandFor(hi: number): HeatBand {
  if (hi >= 46) return 5;
  if (hi >= 44) return 4;
  if (hi >= 41) return 3;
  if (hi >= 38) return 2;
  return 1;
}

function trend(base: number, drift = 0.6): number[] {
  const out: number[] = [];
  let v = base - drift * 6;
  for (let i = 0; i < 12; i++) {
    v += drift * (0.6 + Math.sin(i * 0.9) * 0.3);
    out.push(Number(v.toFixed(1)));
  }
  return out;
}

export const zones: Zone[] = [
  {
    id: "hoan-kiem",
    name: "Hoàn Kiếm",
    district: "Central Hanoi",
    heatIndexC: 46.2,
    band: bandFor(46.2),
    activeDrivers: 316,
    exposed4h: 34,
    eligible: 118,
    mandatory: 34,
    forecastDemand60: 412,
    coolStop: { name: "HydraHub Hoàn Kiếm", distanceKm: 0.7, capacity: 40, partner: "HydraHub" },
    trend: trend(46.2, 0.35),
  },
  {
    id: "hai-ba-trung",
    name: "Hai Bà Trưng",
    district: "South Central",
    heatIndexC: 44.5,
    band: bandFor(44.5),
    activeDrivers: 338,
    exposed4h: 31,
    eligible: 104,
    mandatory: 31,
    forecastDemand60: 386,
    coolStop: { name: "Green Rest Hai Bà Trưng", distanceKm: 1.1, capacity: 32, partner: "Green Rest" },
    trend: trend(44.5, 0.4),
  },
  {
    id: "dong-da",
    name: "Đống Đa",
    district: "West Central",
    heatIndexC: 42.1,
    band: bandFor(42.1),
    activeDrivers: 355,
    exposed4h: 26,
    eligible: 88,
    mandatory: 26,
    forecastDemand60: 402,
    coolStop: { name: "HydraHub Đống Đa", distanceKm: 0.9, capacity: 28, partner: "HydraHub" },
    trend: trend(42.1, 0.5),
  },
  {
    id: "ba-dinh",
    name: "Ba Đình",
    district: "Government Qtr",
    heatIndexC: 40.3,
    band: bandFor(40.3),
    activeDrivers: 284,
    exposed4h: 19,
    eligible: 62,
    mandatory: 19,
    forecastDemand60: 298,
    trend: trend(40.3, 0.55),
  },
  {
    id: "cau-giay",
    name: "Cầu Giấy",
    district: "West",
    heatIndexC: 38.4,
    band: bandFor(38.4),
    activeDrivers: 369,
    exposed4h: 22,
    eligible: 54,
    mandatory: 22,
    forecastDemand60: 348,
    trend: trend(38.4, 0.35),
  },
];

export const cityKpis: CityKpis = {
  activeDrivers: zones.reduce((s, z) => s + z.activeDrivers, 0),
  expectedEscalations60: 47,
  exposed4h: zones.reduce((s, z) => s + z.exposed4h, 0),
  zonesRequiringAction: zones.filter((z) => z.band >= 3).length,
  dataAgeSeconds: 42,
  aiStatus: "ready",
  modelVersion: "heatsafe-v0.9.3 · BQML+Gemini",
};

export function plansFor(zoneId: string): Plan[] {
  const z = zones.find((x) => x.id === zoneId);
  if (!z) return [];
  const mandatory = z.mandatory;

  // Recommended: staggered 3 waves, covers mandatory + buffer
  const recommendedTotal = Math.round(mandatory + Math.max(6, z.eligible * 0.08));
  const w1 = Math.round(recommendedTotal * 0.42);
  const w2 = Math.round(recommendedTotal * 0.34);
  const w3 = recommendedTotal - w1 - w2;

  const recommended: Plan = {
    id: "safepause-staggered",
    label: "SafePause · 3 staggered waves",
    driversPaused: recommendedTotal,
    waves: [
      { index: 1, startMinute: 0, drivers: w1, minutes: 25 },
      { index: 2, startMinute: 10, drivers: w2, minutes: 25 },
      { index: 3, startMinute: 20, drivers: w3, minutes: 25 },
    ],
    recoveryMinutes: 25,
    riskReductionPct: z.band >= 4 ? 38 : 27,
    fulfillmentImpactPct: -2.1,
    etaImpactSec: 34,
    earningsGuardUsd: Math.round(recommendedTotal * 1.85 * 10) / 10,
    netCostUsd: Math.round(recommendedTotal * 1.85 * 10) / 10 + 12,
    costLimitUsd: 480,
    mandatoryCovered: true,
    rationale:
      "Staggered waves keep supply above demand forecast while covering all 4h+ exposed drivers. CoolStop within 1 km supports full 25-min recovery.",
    isRecommended: true,
  };

  const aggressive: Plan = {
    id: "safepause-single",
    label: "Single pause · all mandatory at once",
    driversPaused: mandatory,
    waves: [{ index: 1, startMinute: 0, drivers: mandatory, minutes: 30 }],
    recoveryMinutes: 30,
    riskReductionPct: (z.band >= 4 ? 38 : 27) + 4,
    fulfillmentImpactPct: -6.4,
    etaImpactSec: 92,
    earningsGuardUsd: Math.round(mandatory * 2.1 * 10) / 10,
    netCostUsd: Math.round(mandatory * 2.1 * 10) / 10 + 8,
    costLimitUsd: 480,
    mandatoryCovered: true,
    rationale: "Maximum driver protection but breaches ETA guardrail during peak demand window.",
    infeasibleReason: "ETA impact exceeds +60s guardrail",
  };

  const conservative: Plan = {
    id: "safepause-minimal",
    label: "Mandatory-only · 2 waves",
    driversPaused: mandatory,
    waves: [
      { index: 1, startMinute: 0, drivers: Math.ceil(mandatory / 2), minutes: 25 },
      { index: 2, startMinute: 12, drivers: Math.floor(mandatory / 2), minutes: 25 },
    ],
    recoveryMinutes: 25,
    riskReductionPct: (z.band >= 4 ? 38 : 27) - 8,
    fulfillmentImpactPct: -1.2,
    etaImpactSec: 18,
    earningsGuardUsd: Math.round(mandatory * 1.85 * 10) / 10,
    netCostUsd: Math.round(mandatory * 1.85 * 10) / 10 + 6,
    costLimitUsd: 480,
    mandatoryCovered: true,
    rationale: "Minimum viable coverage. Leaves elective-eligible cohort exposed longer.",
  };

  return [recommended, conservative, aggressive];
}

export const heatLabel = (b: number) =>
  b >= 5 ? "Critical" : b >= 4 ? "Severe" : b >= 3 ? "High" : b >= 2 ? "Elevated" : "Moderate";