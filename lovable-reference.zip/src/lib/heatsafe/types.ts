export type HeatBand = 1 | 2 | 3 | 4 | 5;

export interface CoolStop {
  name: string;
  distanceKm: number;
  capacity: number;
  partner: string;
}

export interface Zone {
  id: string;
  name: string;
  district: string;
  heatIndexC: number;
  band: HeatBand;
  activeDrivers: number;
  exposed4h: number;
  eligible: number;
  mandatory: number;
  forecastDemand60: number; // rides
  coolStop?: CoolStop;
  trend: number[]; // heat trend last 60 min, 12 points
}

export interface PauseWave {
  index: number;
  startMinute: number; // minutes from now
  drivers: number;
  minutes: number;
}

export interface Plan {
  id: string;
  label: string;
  driversPaused: number;
  waves: PauseWave[];
  recoveryMinutes: number;
  riskReductionPct: number;    // model estimate
  fulfillmentImpactPct: number; // negative = drop
  etaImpactSec: number;         // positive = slower
  earningsGuardUsd: number;
  netCostUsd: number;
  costLimitUsd: number;
  mandatoryCovered: boolean;
  rationale: string;
  isRecommended?: boolean;
  infeasibleReason?: string;
}

export interface CityKpis {
  activeDrivers: number;
  expectedEscalations60: number;
  exposed4h: number;
  zonesRequiringAction: number;
  dataAgeSeconds: number;
  aiStatus: "ready" | "stale" | "unavailable";
  modelVersion: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  zone: string;
  plan: string;
  driversPaused: number;
  operator: string;
  simulated: true;
  note?: string;
}